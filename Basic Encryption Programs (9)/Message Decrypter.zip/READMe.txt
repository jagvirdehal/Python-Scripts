Made by: Jagvir
To use the program run DECODER.exe
The DECODER.exe MUST stay in the same folder as ALL the files provided in the zip folder!!!!!!
To paste a message into the Decrypter, right click on the icon in the upper left, go to edit, and click paste.
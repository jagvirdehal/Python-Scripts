Made by: Jagvir
[UPDATE 1.13]: Numbers will now be removed and uppercased letters will now be lower cased automatically
To use the program run CODER.exe
The CODER.exe MUST stay in the same folder as ALL the files provided in the zip folder!!!!!!
DO NOT USE NUMBERS!!!!!!!!!!!
You may use other Characters but they will NOT be encrypted!!!!!!!!!!!!!!!